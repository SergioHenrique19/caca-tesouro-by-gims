/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoppoo2;

/**
 *
 * @author JUDSON
 */
public class ChaveMestra extends Item{
    private int vidaUtil;
    
    public ChaveMestra(int vidaUtil){
        this.vidaUtil = vidaUtil;
    }

    @Override
    public String getDescricao() {
        return "Uma chave capaz de abrir qualquer porta. Possui " + getVidaUtil() + " uso(s) restante(s)";
    }

    public int getVidaUtil() {
        return vidaUtil;
    }
    
    
}
