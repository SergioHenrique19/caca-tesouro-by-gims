/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoppoo2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author JUDSON
 */
public class Jogo {
    //private ManipuladorArquivo manipuladorArquivo;
    private Analisador analisador;
    private Ambiente ambienteAtual;
    private Random gerador;
    private ArrayList<Ambiente> ambientes;
    private int vidaUtilChave;
    private int movimentos;

    public Jogo(){
        //manipuladorArquivo = new ManipuladorArquivo();
        gerador = new Random();
        analisador = new Analisador();
        ambientes = new ArrayList<Ambiente>();
        criarAmbientes();
        movimentos = gerador.nextInt(31) + 20;  
        vidaUtilChave = 0; 
    }

    private void criarAmbientes(){
        ambientes.add(new Ambiente(" no Escritorio", "Escritorio"));
        ambientes.add(new Ambiente(" na Sala de TV", "Sala de TV"));
        ambientes.add(new Ambiente(" na Sala de Jantar", "Sala de Jantar"));
        ambientes.add(new Ambiente(" na Cozinha", "Cozinha"));
        ambientes.add(new Ambiente(" no Jardim", "Jardim"));
        ambientes.add(new Ambiente(" no Corredor", "Corredor"));
        ambientes.add(new Ambiente(" no Quarto 1", "Quarto 1"));
        ambientes.add(new Ambiente(" no Quarto 2", "Quarto 2"));
        ambientes.add(new Ambiente(" no Quarto 3", "Quarto 3"));
        ambientes.add(new Ambiente(" no Quarto 4", "Quarto 4"));
        ambientes.add(new Ambiente(" no Banheiro 1", "Banheiro 1"));
        ambientes.add(new Ambiente(" no Banheiro 2", "Banheiro 2"));

        ajustarSaidasAmbientes();//adicionei para deixar menor. Qualquer coisa só copiar o conteúdo de volta pra cá
        ambienteAtual = ambientes.get(1);  // o jogo comeca na salaTV

        espalharItens();
    }

    private void ajustarSaidasAmbientes(){
        // escritorio 0
        // salaTV 1
        // salaDeJantar 2
        // cozinha 3
        // jardim 4
        // corredor 5
        // quarto1 6
        // quarto2 7
        // quarto3 8
        // quarto4 9
        // banheiro1 10
        // banheiro2 11
        ambientes.get(0).ajustarSaidas("SalaTV", ambientes.get(1));
        ambientes.get(1).ajustarSaidas("Escritorio", ambientes.get(0));
        ambientes.get(1).ajustarSaidas("SalaJantar", ambientes.get(2));
        ambientes.get(1).ajustarSaidas("Jardim", ambientes.get(4));
        ambientes.get(2).ajustarSaidas("SalaTV", ambientes.get(1));
        ambientes.get(2).ajustarSaidas("Cozinha", ambientes.get(3));
        ambientes.get(2).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(3).ajustarSaidas("SalaJantar", ambientes.get(2));
        ambientes.get(3).ajustarSaidas("Jardim", ambientes.get(4));
        ambientes.get(4).ajustarSaidas("SalaTV", ambientes.get(1));
        ambientes.get(4).ajustarSaidas("Cozinha", ambientes.get(3));
        ambientes.get(5).ajustarSaidas("SalaJantar", ambientes.get(2));
        ambientes.get(5).ajustarSaidas("Quarto1", ambientes.get(6));
        ambientes.get(5).ajustarSaidas("Quarto2", ambientes.get(7));
        ambientes.get(5).ajustarSaidas("Quarto3", ambientes.get(8));
        ambientes.get(5).ajustarSaidas("Quarto4", ambientes.get(9));
        ambientes.get(5).ajustarSaidas("Banheiro1", ambientes.get(10));
        ambientes.get(6).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(7).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(8).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(8).ajustarSaidas("Banheiro2", ambientes.get(11));
        ambientes.get(9).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(10).ajustarSaidas("Corredor", ambientes.get(5));
        ambientes.get(11).ajustarSaidas("Quarto3", ambientes.get(8));
    }

    private void espalharItens(){
        
        //armazena o ambiente do tesouro
        Ambiente ambienteTesouro;
        //utilizada para armazenar os nomes das saídas de um ambiente
        String saidasAmbiente[];
        //usado para referenciar os itens criados
        Item item;
        //armazena o número de ambientes do jogo
        int numAmbientes = ambientes.size();
        //recebe um número aleatório de 0 a numAmbientes
        int posicao;
        //nome do arquivo a ser escrito
        String nomeArquivo = "DadosJogo";
        //recebe o texto a ser escrito no arquivo
        String textoArquivo = "";
        
        //Criando o tesouro
        item = new Tesouro(1000);
        posicao = gerador.nextInt(numAmbientes);
        ambienteTesouro = ambientes.get(posicao);
        ambienteTesouro.inserirItemOculto(item);
        textoArquivo += "O Tesouro está no(a): " + ambienteTesouro.getNome() + "\r\n";
        
        
        //Criando dica de onde o tesouro está perto.
        //Pega os nomes dos ambientes adjacentes, os divide em diferentes Strings e coloca as Strings no vetor
        saidasAmbiente = ambienteTesouro.getSaidas().split(" ");
        //Pega um nome aleatório e coloca na dica
        item = new Dica("O tesouro está próximo ao(à) " + saidasAmbiente[gerador.nextInt(saidasAmbiente.length)]);
        posicao = gerador.nextInt(numAmbientes);
        ambientes.get(posicao).inserirItemVisivel(item);
        textoArquivo += "A Dica 'tesouro está perto de' está no(a): " + ambientes.get(posicao).getNome() + "\r\n";

        
        //Criando dica de onde o tesouro não está.
        do {
            posicao = gerador.nextInt(numAmbientes);
        } while(ambienteTesouro == ambientes.get(posicao));
        item = new Dica("O tesouro não está no(a) " + ambientes.get(posicao).getNome());
        posicao = gerador.nextInt(numAmbientes);
        ambientes.get(posicao).inserirItemVisivel(item);
        textoArquivo += "A Dica 'tesouro não está' está no(a): " + ambientes.get(posicao).getNome() + "\r\n";
        
        
        
        //Criando a chave mestra
        item = new ChaveMestra(gerador.nextInt(12) + 1); //soma 1 pois o número aleatório vai de 0 a 11
        posicao = gerador.nextInt(numAmbientes);
        ambientes.get(posicao).inserirItemVisivel(item);
        textoArquivo += "A Chave Mestra está no(a): " + ambientes.get(posicao).getNome() + "\r\n";
        
        escreverArquivo(nomeArquivo, textoArquivo);
    }
    
    /**
     *  Rotina principal do jogo. Fica em loop ate terminar o jogo.
     */
    public void jogar() 
    {            
        imprimirBoasVindas();

        // Entra no loop de comando principal. Aqui nos repetidamente lemos
        // comandos e os executamos ate o jogo terminar.

        boolean terminado = false;
        while (! terminado) {
                Comando comando = analisador.pegarComando();
                terminado = processarComando(comando);
        }
        System.out.println("Obrigado por jogar. Ate mais!");
    }
    
    private void imprimirLocalizacaoAtual(){
        System.out.println("Voce esta " + ambienteAtual.getDescricao());
        System.out.println("Voce tem " + movimentos + " movimentos.");
        System.out.print(ambienteAtual.getSaidas());
        System.out.println();
    }
    
    /**
     * Imprime a mensagem de abertura para o jogador.
     */
    private void imprimirBoasVindas()
    {
            System.out.println();
            System.out.println("Bem-vindo a Caca ao Tesouro!");
            System.out.println("Caca ao Tesouro e um novo jogo de aventura, incrivelmente bacana.");
            System.out.println("Digite 'ajuda' se voce precisar de ajuda.");
            System.out.println();

            imprimirLocalizacaoAtual();
    }
    
    /**
     * Dado um comando, processa-o (ou seja, executa-o)
     * @param comando O Comando a ser processado.
     * @return true se o comando finaliza o jogo.
     */
    private boolean processarComando(Comando comando) 
    {
        boolean querSair = false;

        if(comando.ehDesconhecido()) {
            System.out.println("Eu nao entendi o que você disse...");
            return false;
        }

        String palavraDeComando = comando.getPalavraDeComando();
        if (palavraDeComando.equals("ajuda")) {
            imprimirAjuda();
        }
        else if (palavraDeComando.equals("ir")) {
            if (movimentos > 0){
                    irParaAmbiente(comando);
            }
            else {
                    System.out.println("Parece que acabou seus movimentos, parceiro. Use a bomba voce tem uma chance.");
            }
        }
        else if (palavraDeComando.equals("sair")) {
            querSair = sair(comando);
        }
        else if (palavraDeComando.equals("observar")){
            observar();
        }
        else if (palavraDeComando.equals("detonar")){
            querSair = detonar();
        }

        return querSair;
    }
    
    // Implementacoes dos comandos do usuario

    /**
     * Printe informacoes de ajuda.
     * Aqui nos imprimimos algo bobo e enigmatico e a lista de 
     * palavras de comando
     */
    private void imprimirAjuda() 
    {
            System.out.println("Você esta perdido. Você está sozinho. Você caminha");
            System.out.println("pela casa.");
            System.out.println();
            System.out.println("Suas palavras de comando sao:");
            System.out.println(analisador.getComandos());
    }
    
    /** 
     * Tenta ir em uma direcao. Se existe uma saida entra no 
     * novo ambiente, caso contrario imprime mensagem de erro.
     */
    private void irParaAmbiente(Comando comando) 
    {
        if(!comando.temSegundaPalavra()) {
            // se nao ha segunda palavra, nao sabemos pra onde ir...
            System.out.println("Ir pra onde?");
            return;
        }

        String direcao = comando.getSegundaPalavra();

        // Tenta sair do ambiente atual
        Ambiente proximoAmbiente = null;
        proximoAmbiente = ambienteAtual.getAmbiente(direcao);

        if (proximoAmbiente == null) {
            System.out.println("Nao ha passagem!");
        }
        else {
            boolean usouChave = false;
            
            if(vidaUtilChave != 0) {
                System.out.println("Você deseja usar a chave-mestra? (sim/nao)");
                String confirmacao = analisador.pegarString();
                if(confirmacao.equals("sim")){
                    usouChave = true;
                    usarChave();
                }
            }
            
            if(!usouChave){
                boolean emperrada = gerador.nextBoolean();
                if(emperrada) {
                    proximoAmbiente = ambienteAtual;
                    System.out.println("A porta está emperrada.");
                }
                movimentos--;
            }
            
            while(proximoAmbiente.possuiItemVisivel()){
                coletarItem(proximoAmbiente);
            }
            
            ambienteAtual = proximoAmbiente;
            
            imprimirLocalizacaoAtual();
        }
    }
    
    private void coletarItem(Ambiente ambiente){
        Item item;
        item = ambiente.removeItemVisivel();
        
        if(item instanceof Dica) {
            Dica d = (Dica) item;
            System.out.println("Dica encontrada!");
            System.out.println("Dica: " + d.getDica());
            //MANDAR CONTEÚDO DA DICA PARA INTERFACE
        } else if(item instanceof ChaveMestra) {
            ChaveMestra cm = (ChaveMestra) item;
            vidaUtilChave = cm.getVidaUtil();
            System.out.println("Usos: " + cm.getVidaUtil());
            System.out.println("Chave Mestra encontrada!");
            //MANDAR USOS DA CHAVE PARA INTERFACE (?)
        }
        
    }
    
    private int usarChave() {

        if(vidaUtilChave == 1) {
            System.out.println("Voce utilizou a chave com sucesso. Infelizmente, ela quebrou, e voce nao podera usa-la novamente.");
        }

        else {
            System.out.println("Voce utilizou a chave com sucesso.");
        }

        vidaUtilChave--;

        return vidaUtilChave;
    }

    /** 
     * "Sair" foi digitado. Verifica o resto do comando pra ver
     * se nos queremos realmente sair do jogo.
     * @return true, se este comando sai do jogo, false, caso contrario
     */
    private boolean sair(Comando comando) 
    {
        if(comando.temSegundaPalavra()) {
            System.out.println("Sair o que?");
            return false;
        }
        else {
            return true;  // sinaliza que nos queremos sair
        }
    }
    
    private void observar(){
        imprimirLocalizacaoAtual();
    }
    
    private boolean detonar(){
        if (ambienteAtual.possuiItemOculto()){
            System.out.println("Tesouro encontrado!");
            Tesouro t = (Tesouro)ambienteAtual.removeItemOculto();
            System.out.println("Valor do tesouro: " + t.getValor());
            System.out.println("Parabéns, você ganhou!!!");
        }
        else {
            System.out.println("Não foi dessa vez...");
        }
        return true;
    }
    
    private void escreverArquivo(String nomeArquivo, String texto){
        try{
            ManipuladorArquivo.escreverLinhaArquivo(nomeArquivo, texto);
        }
        catch(IOException e){
            System.out.println("Falha ao escrever no arquivo: " + e.getMessage());
        }
    }
}
