package prototipoppoo2;


import java.io.FileWriter;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author JUDSON
 */
public class ManipuladorArquivo {
    
    public static void escreverLinhaArquivo(String nomeArquivo, String texto) throws IOException{
        FileWriter arq = new FileWriter(nomeArquivo);
        arq.write(texto);
        arq.close();
    }
    
}
