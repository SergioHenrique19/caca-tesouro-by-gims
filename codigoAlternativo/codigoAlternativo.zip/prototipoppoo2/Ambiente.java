/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoppoo2;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author JUDSON
 */
public class Ambiente {
    private String descricao;
    private String nome;
    private HashMap<String, Ambiente> saidas;
    private ArrayList<Item> itensVisiveis;
    private ArrayList<Item> itensOcultos;
    
    
    /**
     * Cria um ambiente com a "descricao" passada. Inicialmente, ele
     * nao tem saidas. "descricao" eh algo como "uma cozinha" ou
     * "
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "um jardim aberto".
     * @param descricao A descricao do ambiente.
     */
    public Ambiente(String descricao, String nome) {
        this.descricao = descricao + " da casa mal assombrada.";
        this.nome = nome;
        saidas = new HashMap<String, Ambiente>();
        itensVisiveis = new ArrayList<Item>();
        itensOcultos = new ArrayList<Item>();
    }
    
    
    /**
     * Define as saidas do ambiente. Cada direcao ou leva a um
     * outro ambiente ou eh null (nenhuma saida para la).
     * @param norte A saida norte.
     * @param leste A saida leste.
     * @param sul A saida sul.
     * @param oeste A saida oeste.
     */
    public void ajustarSaidas(String direcao, Ambiente ambiente) {
        saidas.put(direcao, ambiente);
    }
    
    
    /**
     * @return A descricao do ambiente.
     */
    public String getDescricao(){
        return descricao;
    }

    public Ambiente getAmbiente(String direcao) {
        return saidas.get(direcao);
    }
    
    public String getSaidas() {
        String textoSaidas = "";
        for (String direcao : saidas.keySet()) {
            textoSaidas = textoSaidas + direcao + " ";
        }
        return textoSaidas;
    }
	
    public String getNome() {
        return this.nome;
    }
    
    public void inserirItemVisivel(Item i){
        itensVisiveis.add(i);
    }
    
    public void inserirItemOculto(Item i){
        itensOcultos.add(i);
    }
    
    public Item removeItemVisivel(){
        return itensVisiveis.remove(0);
    }
    
    public Item removeItemOculto(){
        return itensOcultos.remove(0);
    }
    
    public boolean possuiItemVisivel(){
        return itensVisiveis.size() > 0;
    }
    
    public boolean possuiItemOculto(){
        return itensOcultos.size() > 0;
    }
}
