/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoppoo2;

/**
 *
 * @author JUDSON
 */
public class Dica extends Item{
    private String dica;
    
    public Dica(String dica){
        this.dica = dica;
    }

    @Override
    public String getDescricao() {
        return "Uma dica com a mensagem: " + getDica();
    }

    public String getDica() {
        return dica;
    }
      
}
