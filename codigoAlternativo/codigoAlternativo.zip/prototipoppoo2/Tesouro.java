/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoppoo2;

/**
 *
 * @author JUDSON
 */
public class Tesouro extends Item{
    private int valor;

    public Tesouro(int valor) {
        this.valor = valor;
    }

    @Override
    public String getDescricao() {
        return "Um tesouro cujo valor é: " + getValor();
    }

    public int getValor() {
        return valor;
    }
 
}
